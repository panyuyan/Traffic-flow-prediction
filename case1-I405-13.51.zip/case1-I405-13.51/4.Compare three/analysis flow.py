# -*- coding: utf-8 -*-
"""
Created on Fri Apr  2 12:00:48 2021

@author: panyy
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import math
from scipy import stats
from scipy.stats import norm
import seaborn as sns
from matplotlib.font_manager import FontProperties
from scipy.optimize import curve_fit
from sklearn.metrics import mean_squared_error  # 用于评估模型
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error
from math import sqrt
import math
plt.rcParams.update({'figure.max_open_warning': 0})
plt.rc('font',family='Times New Roman')


df = pd.read_csv('Compare.csv')

observed_flow = df['observation']
prediction_flow_lstm = df['prediction_LSTM']
prediction_flow_Markov = df['prediction_Markov']
prediction_final = df['prediction_M_LSTM']
time = df['index']

#analysis

mse_lstm = np.sum((observed_flow - prediction_flow_lstm) ** 2) / len(observed_flow)
mse_Markov = np.sum((observed_flow - prediction_flow_Markov) ** 2) / len(observed_flow)
mse_final = np.sum((observed_flow - prediction_final) ** 2) / len(observed_flow)

rmse_lstm = sqrt(mse_lstm)
rmse_Markov = sqrt(mse_Markov)
rmse_final = sqrt(mse_final)

mae_lstm = np.sum(np.absolute(observed_flow - prediction_flow_lstm)) / len(observed_flow)
mse_Markov = np.sum(np.absolute(observed_flow - prediction_flow_Markov)) / len(observed_flow)
mae_final = np.sum(np.absolute(observed_flow - prediction_final)) / len(observed_flow)

mre_lstm = np.sum(np.absolute(observed_flow - prediction_flow_lstm)/observed_flow) / len(observed_flow)
mre_Markov = np.sum(np.absolute(observed_flow - prediction_flow_Markov)/observed_flow) / len(observed_flow)
mre_final = np.sum(np.absolute(observed_flow - prediction_final)/observed_flow) / len(observed_flow)

r2_lstm = 1-mse_lstm/ np.var(observed_flow)
r2_Markov = 1-mse_Markov/ np.var(observed_flow)
r2_final = 1-mse_final/ np.var(observed_flow)


print('result：')
print('---------------------')
print("MSE LSTM: %.2f" % mse_lstm)
print("MSE Markov: %.2f" % mse_Markov)
print("MSE Final: %.2f" % mse_final)

print('---------------------')
print("RMSE LSTM: %.2f" % rmse_lstm)
print("RMSE Markov: %.2f" % rmse_Markov)
print("RMSE Final: %.2f" % rmse_final)

print('---------------------')
print("MAE LSTM: %.2f" % mae_lstm)
print("MAE Markov: %.2f" % mse_Markov)
print("MAE Final: %.2f" % mae_final)

print('---------------------')
print("MRE LSTM: %.2f" % mre_lstm)
print("MRE Markov: %.2f" % mre_Markov)
print("MRE: %.2f" % mre_final)

print('---------------------')
print("R2 LSTM: %.2f" % r2_lstm)
print("R2 Markov: %.2f" % r2_Markov)
print("R2 Fianl: %.2f" % r2_final)

print('---------------------')
    
# Plot flow
fig = plt.figure(figsize=(5,4))
plt.plot(observed_flow,marker='o', color = 'r',linewidth=2, label = 'observed flow')
plt.plot(prediction_flow_lstm,marker='>',color = 'dodgerblue', linewidth=2, label = 'predicted flow by LSTM')
plt.plot(prediction_flow_Markov,marker='x', color = 'forestgreen', linewidth=2, label = 'predicted flow by Markov')
plt.plot(prediction_final,marker='*', color = 'darkorange', linewidth=2, label = 'predicted flow by final')  

plt.xticks(fontsize=20)
plt.yticks(fontsize=20)
plt.xlabel('Time', fontsize=26)
plt.ylabel('Flow (veh/hr/ln)', fontsize=26)
plt.legend(loc='lower right', fontsize=18)
plt.title('Comparison of observed flow and predicted flow', fontsize=26)
plt.show()
fig.savefig('Comparison of flow2.png', dpi=300, bbox_inches='tight')














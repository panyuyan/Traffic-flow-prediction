# -*- coding: utf-8 -*-
"""
Created on Sun Mar 27 08:56:57 2022

@author: panyy
"""
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 15 22:09:20 2022

@author: panyy
"""
# -*- coding: utf-8 -*-
"""
S3 objection function: density-speed
v=vf/(1+(k/kc)^m)^(2/m)
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import math
from scipy import stats
from scipy.stats import norm
import seaborn as sns
from matplotlib.font_manager import FontProperties
from scipy.optimize import curve_fit
from sklearn.metrics import mean_squared_error  # 用于评估模型
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error
from math import sqrt
import math
plt.rcParams.update({'figure.max_open_warning': 0})
plt.rc('font',family='Times New Roman')
# 1.read data
df = pd.read_excel('CA_I405_bottleneck_13.51_06_all.xlsx')


# 1.read data
df_density1 = df['Density1']
df_speed1 = df['Speed1']

df_density2 = df['Density2']
df_speed2 = df['Speed2']

df_density3 = df['Density3']
df_speed3 = df['Speed3']

df_density4 = df['Density4']
df_speed4 = df['Speed4']

df_density5 = df['Density5']
df_speed5 = df['Speed5']

df_density6 = df['Density6']
df_speed6 = df['Speed6']

df_density7 = df['Density7']
df_speed7 = df['Speed7']

df_density8 = df['Density8']
df_speed8 = df['Speed8']

df_density9 = df['Density9']
df_speed9 = df['Speed9']

df_density10 = df['Density10']
df_speed10 = df['Speed10']

df_density16 = df['Density16']
df_speed16 = df['Speed16']

df_density17 = df['Density17']
df_speed17 = df['Speed17']

df_density18 = df['Density18']
df_speed18 = df['Speed18']

df_density19 = df['Density19']
df_speed19 = df['Speed19']


# plot speed and density
fig = plt.figure(figsize=(5,4))
plt.scatter(df_density1, df_speed1, s =20, marker='o', color = 'k', label = 'state1')
plt.scatter(df_density2, df_speed2, s =20, marker='o', color = 'gray', label = 'state2')
plt.scatter(df_density3, df_speed3, s =20, marker='o', color = 'peru', label = 'state3')
plt.scatter(df_density4, df_speed4, s =20, marker='o', color = 'y', label = 'state4')
plt.scatter(df_density5, df_speed5, s =20, marker='o', color = 'c', label = 'state5')
plt.scatter(df_density6, df_speed6, s =20, marker='o', color = 'sandybrown', label = 'state6')
plt.scatter(df_density7, df_speed7, s =20, marker='o', color = 'limegreen', label = 'state7')
plt.scatter(df_density8, df_speed8, s =20, marker='o', color = 'royalblue', label = 'state8')
plt.scatter(df_density9, df_speed9, s =20, marker='o', color = 'darkorange', label = 'state9')
plt.scatter(df_density10, df_speed10, s =20, marker='o', color = 'gold', label = 'state10')
plt.scatter(df_density16, df_speed16, s =20, marker='o', color = 'r', label = 'state16')
plt.scatter(df_density17, df_speed17, s =20, marker='o', color = 'hotpink', label = 'state17')
plt.scatter(df_density18, df_speed18, s =20, marker='o', color = 'tomato', label = 'state18')
plt.scatter(df_density19, df_speed19, s =20, marker='o', color = 'm', label = 'state19')


plt.xticks(fontsize=16)
plt.yticks(fontsize=16)
plt.xlabel('Density (veh/mi/ln)', fontsize=18)
plt.ylabel('Speed (mi/hr)', fontsize=18)
plt.ylim((0, 85))

#plt.vlines([33],0,2000,linestyles='dashed',colors='k', linewidth = 1)

plt.legend(loc='lower left', fontsize=6)
plt.title('Density vs. speed', fontsize=18)
fig.savefig('./density and speed different state', dpi=220, bbox_inches='tight')
plt.show()
















d


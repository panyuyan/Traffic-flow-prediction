# -*- coding: utf-8 -*-
"""
Created on Sun Mar 27 08:56:57 2022

@author: panyy
"""
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 15 22:09:20 2022

@author: panyy
"""
# -*- coding: utf-8 -*-
"""
S3 objection function: density-speed
v=vf/(1+(k/kc)^m)^(2/m)
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import math
from scipy import stats
from scipy.stats import norm
import seaborn as sns
from matplotlib.font_manager import FontProperties
from scipy.optimize import curve_fit
from sklearn.metrics import mean_squared_error  # 用于评估模型
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error
from math import sqrt
import math
plt.rcParams.update({'figure.max_open_warning': 0})
plt.rc('font',family='Times New Roman')
# 1.read data
df = pd.read_excel('CA_I405_bottleneck_13.51_06_all.xlsx')
#state
df_flow1 = df['Flow1']
df_speed1 = df['Speed1']

df_flow2 = df['Flow2']
df_speed2 = df['Speed2']

df_flow3 = df['Flow3']
df_speed3 = df['Speed3']

df_flow4 = df['Flow4']
df_speed4 = df['Speed4']

df_flow5 = df['Flow5']
df_speed5 = df['Speed5']

df_flow6 = df['Flow6']
df_speed6 = df['Speed6']

df_flow7 = df['Flow7']
df_speed7 = df['Speed7']

df_flow8 = df['Flow8']
df_speed8 = df['Speed8']

df_flow9 = df['Flow9']
df_speed9 = df['Speed9']

df_flow10 = df['Flow10']
df_speed10 = df['Speed10']

df_flow16 = df['Flow16']
df_speed16 = df['Speed16']

df_flow17 = df['Flow17']
df_speed17 = df['Speed17']

df_flow18 = df['Flow18']
df_speed18 = df['Speed18']

df_flow19 = df['Flow19']
df_speed19 = df['Speed19']

# plot flow and speed
xvals=np.linspace(1,95,2000)
fig,ax = plt.subplots(figsize=(5,4))
plt.scatter(df_flow1, df_speed1, s =20, marker='o', color = 'k', label = 'state1')
plt.scatter(df_flow2, df_speed2, s =20, marker='o', color = 'gray', label = 'state2')
plt.scatter(df_flow3, df_speed3, s =20, marker='o', color = 'peru', label = 'state3')
plt.scatter(df_flow4, df_speed4, s =20, marker='o', color = 'y', label = 'state4')
plt.scatter(df_flow5, df_speed5, s =20, marker='o', color = 'c', label = 'state5')
plt.scatter(df_flow6, df_speed6, s =20, marker='o', color = 'sandybrown', label = 'state6')
plt.scatter(df_flow7, df_speed7, s =20, marker='o', color = 'limegreen', label = 'state7')
plt.scatter(df_flow8, df_speed8, s =20, marker='o', color = 'royalblue', label = 'state8')
plt.scatter(df_flow9, df_speed9, s =20, marker='o', color = 'darkorange', label = 'state9')
plt.scatter(df_flow10, df_speed10, s =20, marker='o', color = 'gold', label = 'state10')
plt.scatter(df_flow16, df_speed16, s =20, marker='o', color = 'r', label = 'state16')
plt.scatter(df_flow17, df_speed17, s =20, marker='o', color = 'hotpink', label = 'state17')
plt.scatter(df_flow18, df_speed18, s =20, marker='o', color = 'tomato', label = 'state18')
plt.scatter(df_flow19, df_speed19, s =20, marker='o', color = 'm', label = 'state19')


plt.xticks(fontsize=16)
plt.yticks(fontsize=16)
plt.xlabel('Flow(veh/hr/ln)', fontsize=18)
plt.ylabel('Speed(mi/hr)', fontsize=18)
plt.ylim((0, 85))
plt.xlim((0,2000))
plt.legend(loc='lower left', fontsize=6)
plt.title('Flow vs. speed', fontsize=18)
fig.savefig('./flow and speed different state', dpi=220, bbox_inches='tight')
plt.show()





















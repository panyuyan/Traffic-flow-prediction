# -*- coding: utf-8 -*-
"""
Created on Sun Mar 27 08:56:57 2022

@author: panyy
"""
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 15 22:09:20 2022

@author: panyy
"""
# -*- coding: utf-8 -*-
"""
S3 objection function: density-speed
v=vf/(1+(k/kc)^m)^(2/m)
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import math
from scipy import stats
from scipy.stats import norm
import seaborn as sns
from matplotlib.font_manager import FontProperties
from scipy.optimize import curve_fit
from sklearn.metrics import mean_squared_error  # 用于评估模型
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error
from math import sqrt
import math
plt.rcParams.update({'figure.max_open_warning': 0})
plt.rc('font',family='Times New Roman')
# 1.read data
df = pd.read_excel('CA_I405_bottleneck_13.51_06_all.xlsx')
df_time = df['time']
df_error = df['Flow']



# plot flow and speed
xvals=np.linspace(1,95,2000)
fig,ax = plt.subplots(figsize=(5,4))
plt.plot(df_time, df_error,marker='.', color = 'darkorange', linewidth=0.5)  

plt.xticks(fontsize=16)
plt.yticks(fontsize=16)

#plt.vlines([288],-300, 300,linestyles='dashed',colors='k', linewidth = 1)
#plt.vlines([576],-300, 300,linestyles='dashed',colors='k', linewidth = 1)
#plt.vlines([864],-300, 300,linestyles='dashed',colors='k', linewidth = 1)
#plt.vlines([1152],-300, 300,linestyles='dashed',colors='k', linewidth = 1)

#plt.text(35, -300,"6/19/2017", fontsize=10, color = "k")
#plt.text(325, -300,"6/20/2017", fontsize=10, color = "k")
#plt.text(610, -300,"6/21/2017", fontsize=10, color = "k")
#plt.text(900, -300,"6/22/2017", fontsize=10, color = "k")
#plt.text(1200, -300,"6/23/2017", fontsize=10, color = "k")

plt.xlabel('Time (5-min interval)', fontsize=18)
plt.ylabel('Flow (veh/hr/ln)', fontsize=18)

plt.title('Time series of flow', fontsize=18)
fig.savefig('./Time series of flow', dpi=220, bbox_inches='tight')
plt.show()





















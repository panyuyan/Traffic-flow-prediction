import numpy as np
import pandas as pd
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error
import matplotlib.pylab as plt
from sklearn.preprocessing import MinMaxScaler
plt.rcParams.update({'figure.max_open_warning': 0})
plt.rc('font',family='Times New Roman')
def find_count(s, a, b):
    ab_sum = 0
    for i in range(0, len(s) - 1):
        if (s[i:i + 1] == a) and (s[i + 1:i + 2] == b):
            ab_sum += 1
    return ab_sum


def str_count_df_p(s):
    # 获得里面不重复的元素
    unique_items = np.unique(list(s))
    n = unique_items.size
    df_ = pd.DataFrame(index=unique_items, columns=unique_items)
    for i in unique_items:
        for j in unique_items:
            df_.loc[i, j] = find_count(s, i, j)
    df_ = df_.div(df_.sum(axis=1), axis='index')
    return df_


def markov_prediction(transition_matrix, category):
    return transition_matrix[category].astype(float).idxmax()

def MAPE(y_pre, y_test):
    mape = np.sum(np.fabs((y_test - y_pre) / y_test)) / len(y_test)
    return mape


def Evaluate_TestData(predict_y, test_y):
    mse_score = mean_squared_error(predict_y, test_y)
    mae_score = mean_absolute_error(predict_y, test_y)
    mape_score = MAPE(predict_y, test_y)
    RMSE = np.sqrt(mse_score)
    r = "RMSE: %.4f" % RMSE
    m = "MAE: %.4f" % mae_score
    ma = "MAPE: %.4f" % mape_score
    print ('MAE:', m)
    print ('RMSE:', r)
    print ('MAPE:', ma)
    return r, m, ma

def train_test_split_1dim(normalize_data, time_step, intervals):  # 用minmax做归一化
    data_x, data_y = [], []  # 第一列为t，第二列为t+1
    for i in range(len(normalize_data) - time_step - intervals):
        x = normalize_data[i:i + time_step]
        y = normalize_data[i + time_step + intervals]
        data_x.append(x)
        data_y.append(y)

    # split into train and test sets
    train_x = np.array(data_x[0:len(data_x) - 288])
    train_y = np.array(data_y[0:len(data_x) - 288])
    test_x = np.array(data_x[len(data_x) - 288:])
    test_y = np.array(data_y[len(data_y) - 288:])
    return train_x, train_y, test_x, test_y

path1 = "CA_I405_bottleneck_13.51_06_all.csv"
data = pd.read_csv(path1)
lei = data["state"]
lei_zhi = data.groupby("state").mean()["Flow"]
# 马尔科夫链
transition_matrix = str_count_df_p(list(lei))
transition_matrix.to_csv("transition_matrix.csv")

ndata = data[['state']]

pre_lei = np.ones(len(data))
p = np.ones(len(data))
for i in range(1, len(data)):
    pre_lei[i] = markov_prediction(transition_matrix, int(ndata['state'][i-1]))
    p[i] = lei_zhi[pre_lei[i]]


result = Evaluate_TestData(p[1:], data["Flow"][1:])
plt.plot(p[1:], 'r', label='prediction')
plt.plot(data["Flow"][1:], 'b', label='observation')
plt.xticks(fontsize=16)
plt.yticks(fontsize=16)
plt.xlabel(result)
plt.ylabel('Flow (veh/hr/ln)', fontsize=18)
plt.legend(loc='upper left')
plt.title('Prediction by Markov model', fontsize=18)
plt.savefig(r'Prediction by markov model' + '.jpg', dpi=220, bbox_inches='tight')

data2 = pd.DataFrame([data["Flow"][1:],p[1:]],index=['observation','prediction']).T
#data2 = pd.DataFrame([y[:],p[:]],index=['observation','prediction']).T
data2.to_csv("Markov_prediction.csv")
plt.show()



















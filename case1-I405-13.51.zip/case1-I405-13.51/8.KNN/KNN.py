﻿# -*- coding: utf-8 -*-
"""
Created on Thu Nov  8 10:05:25 2018

@author: 小小贤
"""

import numpy as np
import pandas as pd
from sklearn import neighbors
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error
import math
def knn(fpy,fpx,foy,fox):   
    dfox = fox.T
    dfoy = foy.T
    X = dfox.values #dataframe--narray
    p = ((fpx.T).values).reshape(1, -1)
    Y = dfoy.values
    # #############################################################################
    # Fit regression model
    n_neighbors = 3
    knn = neighbors.KNeighborsRegressor(n_neighbors, weights='distance')
    Y_ = knn.fit(X, Y).predict(p)
    return Y_          

def MAPE(y_pre,y_test): 
    y_pre=(np.array(y_pre.T)).reshape(268)
    y_test=(np.array(y_test.T)).reshape(268)
    npabs=0
    for k in range(len(y_test)):
        if y_test[k] == 0:
            npab=0
        else:
            npab=abs(y_test[k]-y_pre[k])/y_test[k]
        npabs=npabs+npab
    ytest = list(y_test)
    num=ytest.count(0)
    mape=npabs/(len(y_test)-num)
    #np.sum(np.fabs((y_test-y_pre)/y_test))/len(y_test)
    return mape;

def evaluate(predict,origin):
    MAE = mean_absolute_error(predict,origin)
    mse_score = mean_squared_error(predict,origin)
    RMSE = np.sqrt(mse_score)
    mape_score = MAPE(predict,origin)
    r = "RMSE: %.4f" % RMSE
    m = "MAE: %.4f" % MAE
    ma = "MAPE: %.4f" % mape_score
    print ('MAE:', m)
    print ('RMSE:', r)
    print ('MAPE:', ma)
    return r, m, ma
    #return RMSE,MAE,mape_score

f = 'CA_I405_bottleneck_13.51_06_all.csv'
data = pd.read_csv(f)
            #split CREATETIME into DATE and TIME
data.insert(1,'TIME1',data['DateTime']) #先复制原来的列
data["DateTime"] = data["DateTime"].map(lambda x:x.split()[0]) #分别处理新旧两列
data["TIME1"] = data["TIME1"].map(lambda x:x.split()[1])
data.rename(columns={'DateTime':'DATE1'}, inplace=True)
            #establish ID
ids = data['DATE1'] #提取ID
key = ids.drop_duplicates() #对ID去重
key = key.reset_index(drop=True) #reset index 
data = data.sort_values(by=['DATE1','TIME1'],ascending = True)
            #构建knn的横纵坐标
#前两周的数据作为搜索空间
kdata = []
for i in range(0,len(key)-1):
    key[i] = np.array(data['Flow'][data['DATE1'] == key[i]])
    kdata.append(key[i])
fs = (pd.DataFrame(kdata)).T #DataFrame
#用最后一天的数据作为测试
f = data['Flow'][data['DATE1'] == key[len(key)-1]]
f = f.reset_index(drop=True) #DataFrame
            #循环调用
n=20 #步长
pre = []
for i in range(n,288):
    fpy = f.iloc[i]
    fpx = f.iloc[i-n:i-1,]
    foy = fs.iloc[i]
    fox = fs.iloc[i-n:i-1,]
    results = knn(fpy,fpx,foy,fox)
    pre.append(results)
predict = pd.DataFrame(pre)
            #计算RMSE
origin = (pd.DataFrame(f.iloc[n:288,])).reset_index(drop=True)
#origin = f.iloc[n:288,]
evaluation = evaluate(predict,origin)
#a = abs((predict.T).values - (origin.T).values)
#b = np.sum(a**2)
#d = np.sum(a)/np.sum(Y_)


import matplotlib.pylab as plt
#x = range(0,288-n)
plt.plot(predict,'r',label='prediction')
plt.plot(origin,'b',label='origin')
plt.xlabel(evaluation)
plt.ylabel('flow (veh)')
plt.legend(loc='upper left')
plt.title('KNN')
plt.savefig('KNN.jpg')
plt.show()

















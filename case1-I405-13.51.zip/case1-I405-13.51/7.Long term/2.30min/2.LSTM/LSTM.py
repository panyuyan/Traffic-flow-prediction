import math
import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error
from keras.models import Sequential
from keras.layers import LSTM, Dense
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pylab as plt
import re
import joblib
from sklearn.model_selection import GridSearchCV

plt.rcParams.update({'figure.max_open_warning': 0})
plt.rc('font', family='Times New Roman')


def find_count(s, a, b):
    ab_sum = 0
    for i in range(0, len(s) - 1):
        if (s[i:i + 1] == a) and (s[i + 1:i + 2] == b):
            ab_sum += 1
    return ab_sum


def str_count_df_p(s):
    # 获得里面不重复的元素
    unique_items = np.unique(list(s))
    n = unique_items.size
    df_ = pd.DataFrame(index=unique_items, columns=unique_items)
    for i in unique_items:
        for j in unique_items:
            df_.loc[i, j] = find_count(s, i, j)
    df_ = df_.div(df_.sum(axis=1), axis='index')
    return df_


def markov_prediction(transition_matrix, category):
    return transition_matrix[category].astype(float).idxmax()


def train_test_split_1dim(normalize_data, time_step, intervals):  # 用minmax做归一化
    data_x, data_y = [], []  # 第一列为t，第二列为t+1
    for i in range(len(normalize_data) - time_step - intervals):
        x = normalize_data[i:i + time_step]
        y = normalize_data[i + time_step + intervals]
        data_x.append(x)
        data_y.append(y)

    # split into train and test sets
    train_x = np.array(data_x[0:len(data_x) - 288])
    train_y = np.array(data_y[0:len(data_x) - 288])
    test_x = np.array(data_x[len(data_x) - 288:])
    test_y = np.array(data_y[len(data_y) - 288:])
    return train_x, train_y, test_x, test_y


def train_test_split_1dim_n(normalize_data, time_step, intervals, n):  # 用minmax做归一化
    data_x, data_y = [], []  # 第一列为t，第二列为t+1
    for i in range(len(normalize_data) - time_step - intervals - n):
        x = normalize_data[i:i + time_step]
        y = 0
        for j in range(0, n):
            y = y + normalize_data[i + time_step + intervals + j]
        y = y/n
        data_x.append(x)
        data_y.append(y)

    # split into train and test sets
    train_x = np.array(data_x[0:len(data_x) - 288])
    train_y = np.array(data_y[0:len(data_x) - 288])
    test_x = np.array(data_x[len(data_x) - 288:])
    test_y = np.array(data_y[len(data_y) - 288:])
    return train_x, train_y, test_x, test_y


def train_test_split_1dim2(normalize_data, time_step, intervals):  # 用minmax做归一化
    data_x = []
    for i in range(len(normalize_data)):
        x = normalize_data
        data_x.append(x)
    # split into train and test sets
    x = np.array(data_x[0:len(data_x)])
    return x


def lstm_model_onelayer(timesteps, input_dim=1, out_dim=1, unit1=100):
    # expected input data shape: (batch_size, timesteps, data_dim)
    model = Sequential()
    model.add(LSTM(unit1,
                   input_shape=(timesteps, input_dim)))  # returns a sequence of vectors of dimension 32
    model.add(Dense(out_dim, activation='sigmoid'))
    model.compile(loss='mean_squared_error',
                  optimizer='rmsprop')
    # metrics=['accuracy'])
    return model


def MAPE(y_pre, y_test):
    mape = np.sum(np.fabs((y_test - y_pre) / y_test)) / len(y_test)
    return mape


def Evaluate_TestData(predict_y, test_y):
    mse_score = mean_squared_error(predict_y, test_y)
    mae_score = mean_absolute_error(predict_y, test_y)
    mape_score = MAPE(predict_y, test_y)
    RMSE = np.sqrt(mse_score)
    r = "RMSE: %.2f" % RMSE
    m = "MAE: %.2f" % mae_score
    ma = "MAPE: %.2f" % mape_score
    return r, m, ma


def bhz(a):
    b = []
    c = a.values.tolist()
    for i in c:
        if i not in b:
            b.append(i)
    return b


path1 = "CA_I405_bottleneck_13.51_06_all.csv"
data = pd.read_csv(path1)
n=6
# lstm训练
ndata = data[['Flow']]
scale = MinMaxScaler(feature_range=(0, 1))
normalize_data = scale.fit_transform(ndata)


train_x, train_y, test_x, test_y = train_test_split_1dim_n(normalize_data, time_step=4, intervals=1, n=n)
train_y = train_y[:, :1]

model = lstm_model_onelayer(4, input_dim=1, out_dim=1)
MIN_loss = 1
loss_bz = 0
btsz = [1, 4, 16, 64, 128, 256]
# btsz = [16]
# btsz=[256]
for bt in btsz:
    model = lstm_model_onelayer(4, input_dim=1, out_dim=1)
    model.fit(train_x, train_y, batch_size=bt, epochs=max(100, bt))
    zx_loss = min(model.history.history['loss'])
    if zx_loss < MIN_loss:
        loss_bz = bt
        MIN_loss = zx_loss
model.fit(train_x, train_y, batch_size=loss_bz, epochs=max(100, loss_bz))

model.save(r'lstm'+str(n) + '.h5')

# lstm预测
'''
pre_flow = np.zeros(data.shape[0])
for i in range(4, len(data)):
    x1 = ndata[:][i - 4:i].astype('float64')
    x2 = scale.transform(x1)
    x3 = train_test_split_1dim2(x2, time_step=4, intervals=1)
    pre_flow1 = model.predict(x3)
    pre_flow2 = scale2.inverse_transform(pre_flow1)
    pre_flow[i] = pre_flow2[0,0]
data.insert(1,"pre_flow",pre_flow)
'''

p2 = scale.inverse_transform(model.predict(test_x))*n
p = np.ones(p2.shape[0])
for i in range(1, len(p)):
    p[i] = p2[i][:]
y2 = scale.inverse_transform(test_y)*n
y = np.ones(y2.shape[0])
for i in range(1, len(y)):
    y[i] = y2[i][:]

result = Evaluate_TestData(p, y)
plt.plot(p[2:-n], 'r', label='prediction')
plt.plot(y[2:-n], 'b', label='observation')
plt.xticks(fontsize=16)
plt.yticks(fontsize=16)
plt.xlabel(result)
plt.ylabel('Flow (veh/hr/ln)', fontsize=18)
plt.legend(loc='upper left')
plt.title('Prediction by LSTM model', fontsize=18)
plt.savefig(r'Prediction by lstm model' +str(n)+ '.jpg', dpi=220, bbox_inches='tight')
data2 = pd.DataFrame([y[2:], p[2:]], index=['observation', 'prediction']).T
data2.to_csv("LSTM_prediction"+str(n)+".csv")
plt.show()

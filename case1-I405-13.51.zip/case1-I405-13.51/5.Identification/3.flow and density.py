# -*- coding: utf-8 -*-
"""
Created on Sun Mar 27 08:56:57 2022

@author: panyy
"""
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 15 22:09:20 2022

@author: panyy
"""
# -*- coding: utf-8 -*-
"""
S3 objection function: density-speed
v=vf/(1+(k/kc)^m)^(2/m)
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import math
from scipy import stats
from scipy.stats import norm
import seaborn as sns
from matplotlib.font_manager import FontProperties
from scipy.optimize import curve_fit
from sklearn.metrics import mean_squared_error  # 用于评估模型
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error
from math import sqrt
import math
plt.rcParams.update({'figure.max_open_warning': 0})
plt.rc('font',family='Times New Roman')
# 1.read data
df = pd.read_excel('flow and density.xlsx')
df_condensity = df['Density_con']
df_conflow = df['Flow_con']
df_undensity = df['Density_uncon']
df_unflow = df['Flow_uncon']

# plot density and flow
#xvals=np.sort(observed_density)
xvals=np.linspace(0,180,200)
fig = plt.figure(figsize=(5,4))
plt.scatter(df_undensity, df_unflow, s = 20, marker='o')
plt.scatter(df_condensity, df_conflow, s = 20, marker='o')

plt.xticks(fontsize=16)
plt.yticks(fontsize=16)
plt.xlabel('Density (veh/mi/ln)', fontsize=18)
plt.ylabel('Flow (veh/hr/ln)', fontsize=18)
plt.ylim((0, 2000))


plt.vlines([33],0,2000,linestyles='dashed',colors='k', linewidth = 1)

plt.title('Flow vs. density', fontsize=18)
fig.savefig('./flow and density', dpi=220, bbox_inches='tight')
plt.show()







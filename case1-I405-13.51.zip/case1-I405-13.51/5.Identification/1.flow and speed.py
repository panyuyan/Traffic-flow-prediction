# -*- coding: utf-8 -*-
"""
Created on Sun Mar 27 08:56:57 2022

@author: panyy
"""
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 15 22:09:20 2022

@author: panyy
"""
# -*- coding: utf-8 -*-
"""
S3 objection function: density-speed
v=vf/(1+(k/kc)^m)^(2/m)
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import math
from scipy import stats
from scipy.stats import norm
import seaborn as sns
from matplotlib.font_manager import FontProperties
from scipy.optimize import curve_fit
from sklearn.metrics import mean_squared_error  # 用于评估模型
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error
from math import sqrt
import math
plt.rcParams.update({'figure.max_open_warning': 0})
plt.rc('font',family='Times New Roman')
# 1.read data
df = pd.read_excel('flow and speed.xlsx')
df_conflow = df['Flow_con']
df_conspeed = df['Speed_con']
df_unflow = df['Flow_uncon']
df_unspeed = df['Speed_uncon']


# plot flow and speed
xvals=np.linspace(1,95,2000)
fig,ax = plt.subplots(figsize=(5,4))
plt.scatter(df_unflow, df_unspeed, s =20, marker='o')
plt.scatter(df_conflow, df_conspeed, s =20, marker='o')

plt.xticks(fontsize=16)
plt.yticks(fontsize=16)
plt.xlabel('Flow(veh/hr/ln)', fontsize=18)
plt.ylabel('Speed(mi/hr)', fontsize=18)
plt.ylim((0, 85))
plt.xlim((0,2000))

plt.axhline(xmin=0,xmax=2000, y=49,color='k', linestyle='--', linewidth = 1)


plt.title('Flow vs. speed', fontsize=18)
fig.savefig('./flow and speed', dpi=220, bbox_inches='tight')
plt.show()





















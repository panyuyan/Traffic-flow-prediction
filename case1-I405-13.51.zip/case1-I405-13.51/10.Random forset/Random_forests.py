import datetime
import pandas as pd
import numpy as np
from pprint import pprint
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.model_selection import RandomizedSearchCV
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error
from matplotlib.font_manager import FontProperties
from scipy.optimize import curve_fit
from sklearn.metrics import mean_squared_error  # 用于评估模型
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error
from math import sqrt
import math
import numpy as np

f = 'CA_I405_bottleneck_13.51_06_all.csv'
data1 = pd.read_csv(f)

years = data1['Speed']
months = data1['Occupancy']
days = data1['Time']


data1_label = data1['Flow']

data1_feature= data1

data1_lable = np.array(data1_label)
data1_feature = np.array(data1_feature)
data1_train_feature, data1_test_feature, data1_train_label, data1_test_label = train_test_split(data1_feature[:,6], data1_label, test_size = 0.25,
                                                                           random_state = 0)
model_rf = RandomForestRegressor(n_estimators= 100, random_state=0)

model1 = model_rf.fit(np.array(data1_train_feature).reshape(-1,1), np.array(data1_train_label).reshape(-1,1))
model1_prediction = model1.predict(np.array(data1_test_feature).reshape(-1,1))

model1_error = abs(model1_prediction - data1_test_label)
print('error:',round(np.mean(model1_error),2),'degrees')

model1_mape = 100 * np.mean(model1_error / data1_test_label)
print ('MAPE:',round(model1_mape,4))

#model1_accuracy = 100 - model1_mape 
#print('accuracy:', round(model1_accuracy, 4), '%.')


mse_final = np.sum((model1_prediction - data1_test_label) ** 2) / len(data1_test_label)
print('mse_final:',mse_final)

mae_final = np.sum(np.absolute(model1_prediction - data1_test_label)) / len(data1_test_label)
print('mae_final:',mae_final)

rmse_final = sqrt(mse_final)
print('rmse_final:',rmse_final)


mape_final = np.sum(np.absolute(model1_prediction - data1_test_label)/data1_test_label) / len(data1_test_label)
print('mape_final',mape_final)

#r2_final = 1-mse_final/ np.var(data1_test_label)
#print('r2_final',r2_final)







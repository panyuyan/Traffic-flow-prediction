import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime  # 数据索引改为时间
import numpy as np
import statsmodels.api as sm  # acf,pacf图
from statsmodels.tsa.stattools import adfuller  # adf检验
from pandas.plotting import autocorrelation_plot
from statsmodels.tsa.arima_model import ARIMA
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error

data = pd.read_csv('CA_I405_bottleneck_13.51_06_all.csv')


def MAPE(y_pre, y_test):
    mape = np.sum(np.fabs((y_test - y_pre) / y_test)) / len(y_test)
    return mape


def Evaluate_TestData(predict_y, test_y):
    mse_score = mean_squared_error(predict_y, test_y)
    mae_score = mean_absolute_error(predict_y, test_y)
    mape_score = MAPE(predict_y, test_y)
    RMSE = np.sqrt(mse_score)
    r = "mean RMSE: %.4f" % RMSE
    m = "mean MAE: %.4f" % mae_score
    ma = "mean MAPE: %.4f" % mape_score
    return r, m, ma


# 时序图


y =data['Flow'][-288:]
p = {}
for i in range(1152, 288 + 1152):
    model = sm.tsa.ARIMA(data['Flow'][i-4:i], order=(0, 1, 2)).fit()
    pre = model.forecast(1)
    p[i] = pre[i]
p = pd.DataFrame(p,index=[0]).T
p = p[0][:]
y = data['Flow'][1152:]

result = Evaluate_TestData(p, y)
plt.plot(p[:], 'r', label='prediction')
plt.plot(y[:], 'b', label='origin')
plt.xlabel(result)
plt.ylabel('flow (veh)')
plt.legend(loc='upper left')
plt.show()

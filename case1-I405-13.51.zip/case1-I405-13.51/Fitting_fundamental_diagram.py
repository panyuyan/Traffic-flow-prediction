# -*- coding: utf-8 -*-
"""
Created on Sun Mar 27 08:56:57 2022

@author: panyy
"""
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 15 22:09:20 2022

@author: panyy
"""
# -*- coding: utf-8 -*-
"""
S3 objection function: density-speed
v=vf/(1+(k/kc)^m)^(2/m)
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import math
from scipy import stats
from scipy.stats import norm
import seaborn as sns
from matplotlib.font_manager import FontProperties
from scipy.optimize import curve_fit
from sklearn.metrics import mean_squared_error  # 用于评估模型
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error
from math import sqrt
import math
plt.rcParams.update({'figure.max_open_warning': 0})
plt.rc('font',family='Times New Roman')
# 1.read data
df = pd.read_excel('CA_I405_bottleneck_13.51_06_all.xlsx')
df_flow = df['Flow per hour']
df_speed = df['Speed']
df_density = df['Density']

# 2.build S3 model
def S3_density_speed_function(observed_density,free_flow_speed,critical_density,mm):
    k_over_k_critical = observed_density/critical_density
    denominator = np.power(1+np.power(k_over_k_critical,mm),2/mm)
    estimated_speed = free_flow_speed/denominator
    return estimated_speed

# 3.calibration S3 models
param_bounds=([64,20,0],[65,60,15])
popt,pcov = curve_fit(S3_density_speed_function, df_density, df_speed, bounds = param_bounds)

free_flow_speed=popt[0]
critical_density=popt[1]
mm=popt[2]
speed_at_capacity=free_flow_speed/np.power(2,2/mm)
ultimate_capacity=speed_at_capacity*critical_density
print('--free_flow_speed=',free_flow_speed)
print('--speed_at_capacity=',speed_at_capacity)
print('--critical_density=',critical_density)
print('--ultimate_capacity=',ultimate_capacity)
print('--mm=',mm) 



# plot flow and speed
xvals=np.linspace(1,95,2000)
fig,ax = plt.subplots(figsize=(7,5))
plt.plot(xvals*S3_density_speed_function(xvals, *popt), S3_density_speed_function(xvals, *popt),'g--', linewidth=6)
plt.scatter(df_flow, df_speed, s =20, marker='.', c='r', edgecolors='r')
plt.xticks(fontsize=16)
plt.yticks(fontsize=16)
plt.xlabel('Flow(veh/hr/ln)', fontsize=18)
plt.ylabel('Speed(mi/hr)', fontsize=18)
plt.ylim((0, 90))
plt.xlim((0,2000))

plt.title('Flow vs. speed', fontsize=18)
fig.savefig('./flow and speed', dpi=220, bbox_inches='tight')
plt.show()

# plot density and flow
#xvals=np.sort(observed_density)
xvals=np.linspace(0,180,200)
fig = plt.figure(figsize=(7,5))
plt.plot(xvals,xvals*S3_density_speed_function(xvals, *popt),'g--', linewidth=4, label = 'Calibrated curve using S3 model')
plt.scatter(df_density, df_flow, s = 20, marker='.', c='r', edgecolors='r')
plt.xticks(fontsize=16)
plt.yticks(fontsize=16)
plt.xlabel('Density (veh/mi/ln)', fontsize=18)
plt.ylabel('Flow (veh/hr/ln)', fontsize=18)
plt.ylim((0, 2000))

plt.title('Flow vs. density', fontsize=18)
fig.savefig('./flow and density', dpi=220, bbox_inches='tight')
plt.show()

# plot speed and density
fig = plt.figure(figsize=(7,5))
plt.plot(xvals,S3_density_speed_function(xvals, *popt),'g--', linewidth=4, label = 'Calibrated curve using S3 model')
plt.scatter(df_density, df_speed, s = 20, marker='.', c='r', edgecolors='r')
plt.xticks(fontsize=16)
plt.yticks(fontsize=16)
plt.xlabel('Density (veh/mi/ln)', fontsize=18)
plt.ylabel('speed (mi/hr)', fontsize=18)
plt.ylim((0, 90))

plt.title('Density vs. speed', fontsize=24)
fig.savefig('./density and speed', dpi=220, bbox_inches='tight')
plt.show()

















